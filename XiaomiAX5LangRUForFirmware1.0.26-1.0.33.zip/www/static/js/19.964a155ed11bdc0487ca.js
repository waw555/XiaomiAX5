webpackJsonp([19], {
    "5MAP": function(t, i) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANIAAADSCAMAAAAIR25wAAAABGdBTUEAALGPC/xhBQAAAp1QTFRFLH36L377LX/7LX77LoD7LX77LX/7NYD/LH76MID/LoD8Ln76LX36LH37LX77LH77LoD8LX77LX76LH76LoD8LH77LX37LH37Nob/MID/LH37MID7LX36Ln77LH77LH77M4X/LH78LH77LX37M5n/AAAA5O7+c6j7n8P8lb784+7+p8j8l7/8fK77irf8eKz7Ro364ez+eaz7VZb6m8H8ibb8R436V5j7wtn93On+7PP+2+n+ZqH74Oz+h7X8xNr97fT+r879udT9fa778fb+dar7qcr88Pb+rs399/r+ss/97vT+9vn+2Of+stD96/L+1eX++vv+5/D+M4H6Y5/7dKn7aqP7oMT8d6v7O4b6osX8UZP6g7P88vf+bKT7eKv7Xpz7sc/9+/z+9fj+gbH8+Pr+WJj73er+Poj64u3+krz8TpL6gLH81ub+1+b+7/X+RIz6t9P9w9r98/f+q8v9NoP6kbv8rcz99Pj+lb38Yp77cqj7o8b85e/+QIn60eL9ZaD7zN/9/P3+0OL9N4T6NYP6U5X6baX7aKL7tdH9PYf6fa/7kLv8QYr6WZn7k7z8eq37e637/f3+y9/9bqX7Oob6wdn9zuD9OYX6qMn8aaL70+T9MoH6tNH9SI760uP9NYL6t9L9nML8nsP8v9f9kLr8uNP9iLb8OoX6grL8pcf8LX76YJ37xdv9/v7+pMf8ZJ/7NIL6P4j6RYz6UJP6Ln76jrn8Z6H7TZH6PIf6a6T7b6b7z+H9XJv7YZ77sM79vdb9W5r7Vpf7utT9hbT8Qor6s9D9OIT6rc39yt79MH/6yN39lL38qsv9u9X9S5D6j7r8MID6UpT6P4n6n8T8L3/6MYD6wNj9XZv7vtf9Q4v6x9z9////1OX+LH36USTuMgAAACZ0Uk5TbkeDjkiCjxhtEFRv2Pi8rE7v39VY63b+EyDsQNKMRckZlvn0BQCuEuFBAAANRUlEQVR42uWd918TyxqHYwVFpUqRDtl7T++9996r7Rz1HHvXoyiIHguKDcGGCIhipSkgSgcVQSmBhBICCczfcjMbSCNbpmyS3fv9iQ/ZnXmf3dkp77wzo2IEFDfJL35OVNC8BABKAQgDLhVWav3L7r+lAE1h47eUTkwLgIR5QVFz4v0mxQlZrOL7ccbM+FnA6zQrfuYMPCR1gP9s4KWa7R+gRkYKnzYXeLXmTgtHQvKJTgRer8RoH9FI6lAZALFQoWpxSJHBQDYKjhSBpJ4CZKUpaiGkiFggM8VG8CPFBALZKTCGDykkAchQCSHcSL5hQJYK8+VC8gWyla9rpJAw+SKFhbhCikkAMlZCzESkiEAgawVGOCOpY4HMFat2QpoOZK/pjkiRQAGKtEdSBysBKVhthxQKFKFQG1KcxOOjwSKj9tAhrbFoUOLxk48VKVqaHB731bcOFBo6Lo5adbHDUDjQWt/3WJoco8eRwum/pIz0zB2mUR6ZdmSmZ9B/TeFjSJPpplt3WHN1VJSuag7X0c17mgVJTdMX1KJ76Mr4RtPwsKnR1S8Pq1to+o3ULFIAtQSrig2Opatdk1W2qKA/TW/5XZ/WX7CoLEvT7lgmDcVV1EwIYJH86SSWs+uenZk9Ot464HHfn7oeu8vv7cqhY4U/RJpBxadae/lf21NPzj0q5p6jucm2t/rv5VoadsyeYUaaSSGhvnKradsa2lDubGvYZr21vI+CKTPNSPHEqZzotha3Y3vQb99zzFoEu08QGxNvRiKdmxga/4S6qu/gpnGnumv8oxoiNGcWo4ojS8FYMmbL/TOdJOl0nrk/llCJkcyiONVUos7b8gMWO67X3CUtMXdrrlvSOrCcqCs4VeVHcHfTsMWIR810auDmR5b0hpsIEvFT4dcO/QNj7X8ToKamsb7HQD9+/aCag3trxWk283Mn9TQ7afqT59hkT1fgpjBHFYV3Y6+O+HEKvHxdL979UaogvIrugqXQDwEJNGT5RC/gVX1Bqnk4t+3dx2Z6Q6JR6uANNvl9e3FunqfC8LF2Hrc0rUNAMg1Zmt7jGG1dggr9nkvn2ezab0vpRrjdzmZy/hL6rehIZy2NR6seSCp9q6XJOys9UhvbcTE9kN6F9YAdKN5vkxpJe5Ot6YzADTKyNd9NrbRILR0wlyN1wC2qOwJz62iREqmF9Yh0HwRu0kF2JNbYIh2Sln1HV3qB29R7hX1PWqmQ2tjv6FopcKNKr7HfU5s0SGfZuu4acLNYpvtnpUC6xLZHV0rdjVTKlr1Hl+gjdbJ9hu5e4Hb1snXE+U7qSGy/7shB4AEdZOvy47SR9rItbB3wiOrYNncvXSQjHE2YjMBDMsK+0T4jTaRedsT3AHhMD9gxYS9FJHZU3go8KLZfrqOHVMGOj/SeRNKz46cKWkj90BfUdRt4VLfhOPd0PyUk1mUzBDysIdYhRQeJTesG8LhuiHyywkiDsFEYHvQ8klhDhJGKvaLYWYtLMTmS8YDIIuwGwY/6gJEYCc4fnev3DqR+6C8vIUVaCl/2SeAlOinmIxBCgrOWD/XegqSHczX3yJBOwMdCOH+Uv6Bq3crm+vrmleuqFuSTpdUE7TlBhARHX49w83/hl/WXP9rwz4iD/tjw0eX1v7yAmyYcWneTIPXBh9KMkXNlWVL25yM8+jw7qawSI+FmaFEfARKM0LiOXOArUvP+GhGhv/IWViB/pnCOuhwfqRY+khqkHDtrdmwaQdCmHTVoEy410KZabKTL0N2EMPtfmrvskxFkfbIsF8HtdBe63i7jIuXASKczojNLu7FmBFNrbqSJzuYMjKHKwUT6LxwmiS0W2pK/uQxesWn3mxe7ui6+uXvTCq5r/i4R6yTuhAOnXZhIsJmtFtleZN+aaOapVYbU936rdWiK8mt/ey/VsOrUxKtvZYv0bVQLNLc8SFXwQxQV6aTtmfjUu555hy/E8J1nuia+1R5Rb+oOtKsKC2kxjEYTkcXqp52r7I1JL4uoVO6+nLTRuVp/erWIDHv4xxg8SDCi8Zhwo7p2p6NZedUF4uuvguo8x7t3rhVugI/ByEwcpBb4fvcItua7HSz6Phk58rYq+XuHJP4j2FvZAy1rwUDSCfemQGW5Q62QtwRrFqB3icOrulUu9KK28fr0uJFgP76BP+kH79pZsn8LgTf2wZb9dkm9K5BSAxzxoCPVwbfLO/k2eMW+KjasIxs2rDPYV/9XeL0mbdC2OmSkw/zfIACb7aurvDLy8V2ZffHbuJnvUlhzHUZG0pjv0vAVlbds+T/1K51B669P2dJ8i6/w8RrHiQRXguRyJ/rsj7ZS8gQ1J9/gE7ay/OOz3NflwjUoqEgZsLhyxuTf/d32OF+kOkfT9KIt5d852+uj0LoMRKR0vq7D9q22GrekElBVZYmtXdi6na8DkY6IlMlX9V+3ZvpTM6CulJ+syV/nazQzEZHgdE49x2+vWbM8txpIoNWN1gxe47jkT7N5OxCRTDxei4rxDL+QKGSg94vxHCp4/DwmNKTH8PvjGhwYLS39/uek80E+N5YFlwOczz4V+lMAIJV1yNUACVXzB8wjlfN3nlLEgVQPJ2e5M3z1290XNgNJtfnC7m9f5f6Z51vnQGoV6Dt4XBruKX4OJDiTk+XNSFncs14cSIXmO8q8GanMbGAhElK2WE+KpwR9KtlISDDis8CbkQpgfCgSElwpT2k2s23pS8nnv+p5//2er84nv7S0jU6q/XANPwpSPmzJtpP3AlKSDF87O+u+NiSlkPc6tkML8xGQiuANhNOZaZ8W7uRyF+8s/DSNLHU9tLAIAckIo7OJslz54Qp+z/6KD1cSZQAj1o0ISFre/pCgSuf/IGa+4of5BLG/sEekRUA6BENbsHNreFvsJMzbDdiZwOibQ25Cej0PZWYp73U3IeEXvEsLnedZbq25+Zmu+PmGhueLdZ/dXOM8aXNq4SW3FDzs6sHJRX6r8ckap2qpqObJRkes3c3uqB5wK/Fr9m7gkY71HK11//oO++v2Yyx6QK7EB+ENyC1HzlU7O/8p5532ri23D/G4irwnRxq0cFDqDtHPG2w2fvNKkdDlZ1/5xnb9hp+l7hBhdVurbZ9Qt6jY3tvdto+qGjEz9G4rzuDCOvWwSnSM5dAq68QHYmaLuGchKA4Bl41ZN4DgIh8c90Qvk3wIiDNQb7JUC4gdggZLNYEaIIc+UMdyp3z8pbniRl0yCrTmCv3Lj6V3pwg4vThUOYS1l1DtEPpUAbrTq4+sKy690F2TvA5kLxCGA5nXze8FwnDz807GeIFwJmMyRa+A8ohwpszSRcZEeUg4E5v808+eFtb0s1CQgGeFFSQgGMrhUSVjhXIIBtx4UngBN8JhUZ4TZliUmOA1TwkzeI2t+rd5J9I23tBo0kBQTwg7EFRkuK4Y9aas/e6NN75bm0In9AM7XJddqkmjA3F74INxD8MHAzTWUOMHVYsPfedVq8Ms007yNccEoe8oCxR4aidnx/4Z0hQJFiiAXSjLSLiU6oyUSpgg0TISxMU+rrXEGWk+YYJEi32Ql2S51CNHokeEyZEtycJZOOfChi32RFtInxDhwjm85Y3O0tstBeohXnVMuLwRfxGq4wdt9ZYbSCsb8kWoZEuFrRoci1jeSh5QTrxUmMqCbrPyTZDIlE+cEIUF3bSW3VfeHBm5SR5RTmPZvWUnDBqbI6SkUEiEyuYICtzCQokbjYDl3rUdzHJAjqTATXu8a2slEQ3K/+cGWErcpkyBm8kpccs/JW7MqMDtM5W4yakSt6JV4obBCtzWWYmbbytxi3QlbmSvxOMGrIdCLHBTe+SGQyGUeHSHEg9YUeIxODI4rEiBR0op8OAvBR7PpsBD9BR41KECD6T0Iy/09I8NJflE/QgPdy2W4nDXYqKKdJISj+BV4EHJSjzOmvKh492oh4530z90XIKj4TVij4bXSHM0PONPpwbO2XVv1KYeXX0f3+66ffW6HrvL7+3KoWOFPwORAqg1lFWLDaP2MrVrssruFPRvH+tg6Lf3F9wpy9K0mxwuMyyuomZCAIuknkuxQ9OiezjqQo2m4WFTo6tfHupaKGY/V80iMdMoO0EOa66OitJVzWHKEwfTGAtSeCL18UFGeqZT6XKSqT0zPYN6tonhY0hMtDQjOXMd0DpQmN1x0UZysSO7cKCVt+YgUTQzjuSTCCRVfpFRe+iQ1liUL20+iT5WJCYUKEKhjA1JHawEomC1HRITqQSkSMYeiZkuf6IpjCOSOlbuRLFqJyQmIlDeRIERjDMSE5MgZ6KEGGYiEhMSJl+isBDGFRKjki+SL+MaiVHJ9D2F+TJcSEyILL+nhBCGG4mJkWG9FxjD8CExEbJrn2IjGH4kRi2zfsR0NSOEZO7vyagPGxw50X4XSIw6NFEeQImhakYcEsPERcsAKjHax6XxrpEYJnzyXO8Gmjs5nMN0LiRz8Qvwn+2tPLP9A9SchnMjmTVjZvws7+OZFT9zBp/VvEjsZzXVL35OVNA8j/crEuYFRc2J95saJ2Tx/wCk8mnAd4aqDgAAAABJRU5ErkJggg=="
    },
    PstU: function(t, i) {},
    "dLd/": function(t, i) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAE10lEQVR42u3dS0wcdRwH8F+86MGEapvUUhtrfd41Jp6M8SKltBYKBXZ5LtDlYYpQErC2lsRYPTSNiGkkJsSqvenFRqO0FV8HSvXQNEFTXaCJMG8ou+wCA/v1MEPalGV3gQUm6XeSbzYBdh7/DzO7M/n9ZgSARL/tKDObd13XAzJl1DMbGT0gU1bLruvT37xVsWCOiMwOfFGovC7QSgVGo8CoZzY0jQLNJ1D2CWKXz/jFan1kTCsmxqajFAustm3/il4lMJo4KJsdvVpgtmSNi3ss46BsNkilwGrfESIIQRiCEIQhCEEYghCEIQhBCEIQhiAEYQhCEIYgBGEIQhAOCEEYghCEIQhBGC+DNAiMIwK9ylmAXrXBWVxmjcAIrm079Nok2+D+3DjibrOXQfSAOxiblTqBXi5QDwrUAwK9wh20lQxc0CntTLUsvdrjIGqBINzrw4IR2qQMY175G/bwAGZ+Poeprv0w6h+CmufCNKWHoRULYlc+woIxnHR54V4f1AIPgyh7BbErXfDStDAxjumv34HuF6hvuCjJ/qvrHJD5/26knHfspy4oe70MkieIXjwFL0726CCstmcdlMYUICWCuaFLKecZvXgKSh5B1jDNwmp7EuoBgfEmQTwxxSPjMKofdDrGGgjijf3kzy+h5nEP8dQ08fZOqEUEuftjFvHZacTt2OoyF0N8NgrEVwcS/a4T6r4Eh637EWR+7AbM5myYRx+F1bZt1TFbt8Jq343bZ3IQu/TJyr4OazfvnNXf7yBzQz9CyRWoxQLNv8aUOmfk468JJt9/eQXfg2MwWx+GVkYQ2P/8Cs3vXC/K2DW0oGD8VUHkfGnaJtbxJ6CVECTzIIsoNQJ1v8Ae6kvvg/3k0wRZNxC3AV/JEYR78tMDObGHIElBGp1Dj5rvXHdKFq0s8dm2WiCY/OBFgmQEpE5gBB/A1Lk8hD8vR7i3NEF8CPf6MXHyKeiVCUAOCSZPv0CQTIBoJYKJ47vTGsyZ33qc84hgApAPXyJIRkCKBRPvPpPWYMb6u50rtwRZ5z3kxJ70QC6fJQhBCEIQghCEIAQhCEEIQhCCEIQgBCEIQQhCEIIQhCAEIQhBCEIQgiQByRHM9Henrqs1R6D5ltbVakWCyc7n0mspuPpV4iKHg4LbZ19Jax6Tnc9DK0oAclgwr/yVutCivxtKjpebPgsF4U/zYY9chT066Lzem9FriP5wGprPbSu+Z6XM5izMDfXBvnVtmfcPwh4dROR8JbTCBBvmF1jtj8O++Qvs0WXmcesPzA31wWzesrSUKOjUC0e/f2/597vbFu45BLXQy23RTU63q17h9nJXJEil3ClwblhaKKfXOM9kSvb+xd8l7BVsclqztbIU67C4hy7Tb6iXp1gH9zVTTydavxsHBJ0NXTYBtyAuSSesXuv8XbL5pGraTzqPgMCoTeMGCKnWIej1GwcwBCEIQxCCMAQhCEEIwhCEIAxBCMIQhCAMQQhCEIIwBCEIQxCCMAQhCEMQghDEayB6VebKIZk1gFQLzNYtY2Id2zqmlUjyZ2ow65tGp8DbbMkKyczvnx1Wct3i4+q7ipmZjUm1U7Gv5Api/R+XSzxiSuRCoMps3jlgtW4PWR3ZIat9B7MR6cgOWce2h8yjjw1ELtQGYMfkf5WIKSpa6fvoAAAAAElFTkSuQmCC"
    },
    mQzm: function(t, i, s) {
        "use strict";
        Object.defineProperty(i, "__esModule", {
            value: !0
        });
        var r = {
                name: "error",
                data: function() {
                    return {}
                },
                components: {},
                methods: {
                    downloadEvent: function() {
                        var t = "",
                            i = this.common.detectDevice();
                        "ios" == i ? t = "https://itunes.apple.com/cn/app/id1361950738?mt=8" : "android" == i && (t = "http://bigota.miwifi.com/xiaoqiang/miwifichain/wifichain_release.apk"), window.location.href = t
                    }
                }
            },
            v = {
                render: function() {
                    var t = this,
                        i = t.$createElement,
                        s = t._self._c || i;
                    return s("div", {
                        staticClass: "container"
                    }, [t._m(0), t._v(" "), s("div", {
                        staticClass: "cont"
                    }, [s("div", {
                        staticClass: "connect"
                    }, [t._v("\n            Подключен\n        ")]), t._v(" "), s("div", {
                        staticClass: "desc"
                    }, [t._v("\n            Рекомендуется установить приложение Xiaomi WiFi, чтобы управлять маршрутизатором в любое время и в любом месте.\n        ")]), t._v(" "), t._m(1), t._v(" "), s("div", {
                        staticClass: "desc_app"
                    }, [t._v("\n            Приложение Xiaomi WiFi\n        ")]), t._v(" "), s("div", {
                        staticClass: "download",
                        on: {
                            click: t.downloadEvent
                        }
                    }, [s("div", {
                        staticClass: "down"
                    }, [t._v("\n                Скачать\n            ")]), t._v(" "), s("div", {
                        staticClass: "desc_down"
                    }, [t._v("\n                Приложение Xiaomi WiFi\n            ")])])])])
                },
                staticRenderFns: [function() {
                    var t = this.$createElement,
                        i = this._self._c || t;
                    return i("div", {
                        staticClass: "logo"
                    }, [i("img", {
                        attrs: {
                            src: s("dLd/"),
                            alt: ""
                        }
                    })])
                }, function() {
                    var t = this.$createElement,
                        i = this._self._c || t;
                    return i("div", {
                        staticClass: "wifi_logo"
                    }, [i("img", {
                        attrs: {
                            src: s("5MAP"),
                            alt: ""
                        }
                    })])
                }]
            };
        var n = s("VU/8")(r, v, !1, function(t) {
            s("PstU")
        }, "data-v-602ec61a", null);
        i.default = n.exports
    }
});